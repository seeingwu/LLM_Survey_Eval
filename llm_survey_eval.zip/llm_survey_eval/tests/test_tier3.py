from __future__ import annotations
import numpy as np
import pandas as pd
from llm_survey_eval.tier3_alt import compute_global_metrics

def _toy(n: int=150, seed: int=0):
    rng = np.random.default_rng(seed)
    ordered = [
        "shopping_frequency","leisure_frequency","service_frequency",
        "shopping_satisfaction","leisure_satisfaction","service_satisfaction",
    ]
    nominal = ["shopping_mode","leisure_mode","service_mode"]
    human = pd.DataFrame({"agent_id": np.arange(n)})
    llm   = pd.DataFrame({"agent_id": np.arange(n)})
    for c in ordered:
        human[c] = rng.integers(1,7,size=n)
        llm[c]   = np.clip(np.rint(human[c] + 0.3*rng.normal(size=n)),1,6).astype(int)
    cats = np.arange(1,8)
    p = np.array([0.15,0.15,0.2,0.15,0.1,0.1,0.15])
    q = np.array([0.10,0.14,0.22,0.18,0.14,0.10,0.12])
    for c in nominal:
        human[c] = rng.choice(cats,size=n,p=p)
        llm[c]   = rng.choice(cats,size=n,p=q)
    return human, llm, ordered, nominal

def test_tier3_alt_interface_and_ranges():
    human, llm, ordered, nominal = _toy()
    nom_cats = {c: [1,2,3,4,5,6,7] for c in nominal}
    res = compute_global_metrics(human, llm, ordered, nominal, nominal_categories=nom_cats, verbose=False, seed=7, mmd_max_samples=256)
    for k in ["energy_distance","mmd_gaussian","mmd_bandwidth","c2st_auc"]:
        assert k in res and isinstance(res[k], float)
    assert res["energy_distance"] >= 0.0
    assert res["mmd_gaussian"] >= 0.0
    assert 0.5 <= res["c2st_auc"] <= 1.0
